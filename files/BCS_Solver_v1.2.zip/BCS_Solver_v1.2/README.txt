================================================================================
                    BCS Solver v1.2 - Boolean Polynomial System Solver
================================================================================

BCS Solver is a high-efficiency solver for Boolean polynomial systems over GF(2) based on the
characteristic set method described in:

  "On the efficiency of solving Boolean polynomial systems with the
   characteristic set method"

Author: Zhenyu Huang

This version is an improved version by using Delayed Copy Trick in Generate_Newbranches function;

Author: Minzhong Luo
Email:luominzhong@swust.edu.cn

================================================================================
                               QUICK START
================================================================================

1. Extract all files to a folder (keep all DLL files in the same directory as
   bcs_solver.exe)

2. Open Command Prompt (cmd.exe) and navigate to the folder:

   cd C:\path\to\BCS_Solver_v1.2

3. Run the solver with an input file:

   bcs_solver.exe examples\EQUATIONS_n20_m20_0.txt

================================================================================
                              INPUT FORMAT
================================================================================

The input file should contain Boolean polynomials over GF(2), one per line.

Format:
- Variables are named x0, x1, x2, ..., xN
- Multiplication is represented by '*' (e.g., x0*x1)
- Addition (XOR in GF(2)) is represented by '+'
- Constant 1 is written as '1'
- Each polynomial should end with ';'

Example (a system with 3 variables):
--------------------------------------------------------------------------------
x0*x1 + x0*x2 + x1 + 1;
x0*x2 + x1*x2 + x0 + x2;
x0*x1*x2 + x0 + x1 + x2 + 1;
--------------------------------------------------------------------------------

================================================================================
                              OUTPUT FILES
================================================================================

The solver generates the following output files in the working directory:

1. input_poly.txt     - Echo of the input polynomial system
2. poly_elimination.txt - Polynomials after pre-elimination
3. file_result.txt    - Final monic triangular sets (solutions)
4. time.txt           - Timing and statistics log (appended)

================================================================================
                           INCLUDED FILES
================================================================================

bcs_solver.exe        - Main executable
cygwin1.dll           - Cygwin runtime library (required)
cygstdc++-6.dll       - C++ standard library (required)
cyggcc_s-seh-1.dll    - GCC support library (required)
README.txt            - This file
examples/             - Sample input files
  EQUATIONS_n20_m20_0.txt - 20 variables, 20 equations (easy)
  EQUATIONS_n20_m20_1.txt - 20 variables, 20 equations (easy)
  EQUATIONS_n25_m25_1.txt - 25 variables, 25 equations (medium)

================================================================================
                            SYSTEM REQUIREMENTS
================================================================================

- Operating System: Windows 7/8/10/11 (64-bit)
- Memory: At least 4GB RAM recommended for large systems
- No additional software installation required

================================================================================
                               USAGE TIPS
================================================================================

1. For large polynomial systems (>30 variables), expect longer computation times

2. The solver outputs progress information to the console:
   - Number of input polynomials
   - Pre-elimination progress
   - Zero-decomposition progress (with branch counts)
   - Final solution count and timing

3. Running from PowerShell:
   .\bcs_solver.exe .\examples\EQUATIONS_n20_m20_0.txt

4. Running from CMD:
   bcs_solver.exe examples\EQUATIONS_n20_m20_0.txt

================================================================================
                                LICENSE
================================================================================

This software is provided for academic and research purposes.
Please cite the paper if you use this software in your research.


================================================================================
